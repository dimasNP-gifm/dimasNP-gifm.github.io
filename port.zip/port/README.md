# Portfolio Website

A modern, responsive portfolio website with an easy-to-use content management system for updating photos and text without touching the code.

## Features

- **Modern Design**: Clean, professional layout with smooth animations
- **Fully Responsive**: Works perfectly on desktop, tablet, and mobile devices
- **Content Management System**: Update text and images through a simple UI
- **Portfolio Gallery**: Filterable portfolio items with modal view
- **Contact Form**: Functional contact form with notifications
- **Smooth Scrolling**: Navigation with smooth scroll animations
- **Local Storage**: All changes are saved automatically

## Quick Start

1. **Open the website**: Simply open `index.html` in your web browser
2. **Access Content Manager**: Click the edit button (📝) in the bottom-right corner
3. **Update Content**: Use the content manager panel to update text, images, and add portfolio items

## Content Management Guide

### Updating Text Content

1. Click the edit button (📝) in the bottom-right corner
2. In the "Update Text" section:
   - Select the text element you want to update (Hero Title, About Text, etc.)
   - Enter your new text in the input field
   - Click "Update" to save changes

### Updating Images

1. In the "Update Images" section:
   - Select which image to update (Profile Image, About Image)
   - Enter the new image URL
   - Click "Update" to save changes

### Adding Portfolio Items

1. In the "Add Portfolio Item" section:
   - Enter the project title
   - Write a description
   - Provide an image URL
   - Select a category (Design, Development, Photography)
   - Click "Add Item" to add to your portfolio

### Available Text Elements

- **Hero Title**: Main heading on the homepage
- **Hero Subtitle**: Subheading below the main title
- **Hero Description**: Introduction paragraph
- **About Text**: About section description
- **Contact Text**: Contact section description
- **Contact Email**: Email address
- **Contact Phone**: Phone number
- **Contact Location**: Physical location

## Customization

### Colors and Styling

The main brand color is `#4F46E5` (indigo). You can customize colors by editing the CSS variables in `styles.css`:

```css
:root {
    --primary-color: #4F46E5;
    --secondary-color: #10B981;
    --accent-color: #F59E0B;
}
```

### Adding New Sections

1. Add the HTML structure to `index.html`
2. Add corresponding styles to `styles.css`
3. Add any JavaScript functionality to `script.js`

### Portfolio Categories

Default categories are:
- Design
- Development  
- Photography

To add new categories:
1. Update the filter buttons in `index.html`
2. Add the new category option in the content manager
3. Update the CSS styling if needed

## File Structure

```
portfolio-website/
├── index.html          # Main HTML structure
├── styles.css          # All styling and responsive design
├── script.js           # Interactive features and content management
└── README.md           # This documentation
```

## Browser Compatibility

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Tips for Best Results

### Images
- Use high-quality images (minimum 800x600px for portfolio items)
- Optimize images for web (JPEG for photos, PNG for graphics)
- Maintain consistent aspect ratios for portfolio items

### Text Content
- Keep titles concise and impactful
- Write clear, engaging descriptions
- Use proper grammar and spelling

### Portfolio Items
- Showcase your best work
- Include diverse projects
- Provide detailed descriptions
- Use professional-quality images

## Data Persistence

All changes are automatically saved to your browser's local storage. This means:
- Your content persists between browser sessions
- No database required
- Changes are specific to your browser/device

**Note**: Clearing browser data will reset all content to defaults.

## Deployment

To deploy this portfolio:

### Option 1: GitHub Pages
1. Push all files to a GitHub repository
2. Enable GitHub Pages in repository settings
3. Select main branch as source

### Option 2: Netlify/Vercel
1. Drag and drop the folder to Netlify/Vercel
2. Or connect your Git repository

### Option 3: Traditional Hosting
1. Upload all files to your web server
2. Ensure the server supports static files

## Support

If you encounter any issues:
1. Check browser console for errors
2. Ensure all files are in the same directory
3. Try refreshing the page
4. Clear browser cache if needed

## License

This portfolio template is free to use and modify for personal and commercial projects.
